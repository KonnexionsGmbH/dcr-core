# dcr-core
Document Content Recognition API
